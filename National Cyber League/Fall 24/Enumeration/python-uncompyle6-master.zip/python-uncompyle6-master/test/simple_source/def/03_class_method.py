# From Decompyle++
# File: 22_class_method.pyc (Python 2.2)
# An old-style Python class.

class MyClass:

    def method(self, i):
        if i is 5:
            print 'five'
        elif not (i is 2):
            print 'not two'
        else:
            print '2'
