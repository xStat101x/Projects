# Addresses a bug in the way Python 3.5+ handles
# creation of map constants
opts = {'highlight': True,
            'start_line': -1,
            'end_line': None
            }
print(opts)
