# Tests:
# assign ::= expr store
pass
