# Tests relative imports
from . import bogus
from .. import foo
from ..bar import baz
