#!/usr/bin/env python
"""Setup script for the 'uncompyle6' distribution."""

from setuptools import setup

setup(packages=["uncompyle6"])
